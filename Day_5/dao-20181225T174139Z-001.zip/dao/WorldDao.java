package dayfive.streams.dao;


public interface WorldDao extends CountryDao,CityDao {

}
